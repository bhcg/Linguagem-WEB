<?php

include_once '../Conexao.php';

$sql = "select * from cargo";

$conexao = new Conexao();
$cargos = $conexao->recuperarTodos($sql);

include_once '../cabecalho.php';
?>

    <h1>Cargo</h1>

    <a class="btn btn-warning" href="formulario.php">Novo</a>

    <table class="table table-bordered table-striped table-hover">
        <tr>
            <td>ID</td>
            <td>Nome</td>
        </tr>
        <?php
        foreach ($cargos as $cargo) {
            echo "
                <tr>
                    <td>{$cargo['id_cargo']}</td>
                    <td>{$cargo['nome']}</td>
                </tr>
            ";
        }
        ?>
    </table>

<?php include_once '../rodape.php'; ?>