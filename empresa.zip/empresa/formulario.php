<?php
include_once 'Empresa.php';

$empresa = new Empresa();

if(!empty($_GET['id_empresa'])){
    $empresa->recuperarPorId($_GET['id_empresa']);
}

include_once '../cabecalho.php';
?>

    <div class="row">
    	<div class="col-md-12">

    		<div class="box box-danger">
    			<div class="box-header with-border">
    				<h3 class="box-title">Empresa</h3>
    			</div>
    			<div class="box-body">
    				<div class="row">
    					<div class="col-md-12">
                            <form action="processamento.php?acao=salvar" method="post">

                                <input type="hidden" name="id_empresa" id="id_empresa" value="<?php echo $empresa->getIdEmpresa(); ?>">

                                <div class="form-group row">
                                    <label for="nome" class="col-sm-2 col-form-label">Razão Social:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="razaosocial" id="razaosocial" value="<?php echo $empresa->getRazaoSocial(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="matricula" class="col-sm-2 col-form-label">Nome Fantasia:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="nomefantasia" id="nomefantasia" value="<?php echo $empresa->getNomeFantasia(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="salario" class="col-sm-2 col-form-label">CNPJ:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="cnpj" id="cnpj" value="<?php echo $empresa->getCnpj(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="telefone" class="col-sm-2 col-form-label">Data Fundação:</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" name="datafundacao" id="datafundacao" value="<?php echo $empresa->getDataFundacao(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="endereco" class="col-sm-2 col-form-label">Capital Inical:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="capitalinicial" id="capitalinicial" value="<?php echo $empresa->getCapitalInicial(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-success">Enviar</button>
                                        <a class="btn btn-danger" href="index.php">Voltar</a>
                                    </div>
                                </div>
                            </form>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>






<?php include_once '../rodape.php'; ?>