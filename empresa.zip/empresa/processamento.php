<?php

include_once 'Empresa.php';

$empresa = new Empresa();

switch ($_GET['acao']){
    case 'salvar':
        if(empty($_POST['id_empresa'])){
            $empresa->inserir($_POST);
        } else {
            $empresa->alterar($_POST);
        }
        break;
    case 'deletar':
        $empresa->deletar($_GET['id_empresa']);
        break;
}

header('location: index.php');