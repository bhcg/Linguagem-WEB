<?php

include_once '../Conexao.php';

class Empresa{

    protected $id_empresa;
    protected $razao_social;
    protected $nome_fantasia;
    protected $cnpj;
    protected $data_fundacao;
    protected $capital_inicial;   

    /**
     * @return mixed
     */
    public function getIdEmpresa()
    {
        return $this->id_empresa;
    }

    /**
     * @param mixed $id_empresa
     */
    public function setIdEmpresa($id_empresa)
    {
        $this->id_empresa = $id_empresa;
    }

    /**
     * @return mixed
     */
    public function getRazaoSocial()
    {
        return $this->razao_social;
    }

    /**
     * @param mixed $razao_social
     */
    public function setRazaoSocial($razao_social)
    {
        $this->razao_social = $razao_social;
    }

    /**
     * @return mixed
     */
    public function getNomeFantasia()
    {
        return $this->nome_fantasia;
    }

    /**
     * @param mixed $nome_fantasia
     */
    public function setNomeFantasia($nome_fantasia)
    {
        $this->nome_fantasia = $nome_fantasia;
    }

    /**
     * @return mixed
     */
    public function getCnpj()
    {
        return $this->cnpj;
    }

    /**
     * @param mixed $cnpj
     */
    public function setCnpj($cnpj)
    {
        $this->cnpj = $cnpj;
    }

    /**
     * @return mixed
     */
    public function getDataFundacao()
    {
        return $this->data_fundacao;
    }

    /**
     * @param mixed $data_fundacao
     */
    public function setDataFundacao($data_fundacao)
    {
        $this->data_fundacao = $data_fundacao;
    }

    /**
     * @return mixed
     */
    public function getCapitalInicial()
    {
        return $this->capital_inicial;
    }

    /**
     * @param mixed $capital_inicial
     */
    public function setCapitalInicial($capital_inicial)
    {
        $this->capital_inicial = $capital_inicial;
    }

    public function inserir($dados)
    {
        
        $razao_social = $dados['razaosocial'];
        $nome_fantasia = $dados['nomefantasia'];
        $cnpj = $dados['cnpj'];
        $data_fundacao = $dados['datafundacao'];
        $capital_inicial = $dados['capitalinicial'];

        $conexao = new Conexao();
        
        $sql = "insert into empresa (razao_social) values ('$razao_social')";

        return $conexao->executar($sql);
    }

    public function alterar($dados)
    {
        $razao_social = $dados['razaosocial'];
        $nome_fantasia = $dados['nomefantasia'];
        $cnpj = $dados['cnpj'];
        $data_fundacao = $dados['datafundacao'];
        $capital_inicial = $dados['capitalinicial'];

        $sql = "update empresa set 
                    id_empresa = '$id_empresa' 
                where id_empresa = $id_empresa";
        $sql = "update empresa set 
                    razao_social = '$razao_social' 
                where id_empresa = $id_empresa";
        $sql = "update empresa set 
                    nome_fantasia = '$nome_fantasia' 
                where id_empresa = $id_empresa";
        $sql = "update empresa set 
                    cnpj = '$cnpj' 
                where id_empresa = $id_empresa";
        $sql = "update empresa set 
                    data_fundacao = '$data_fundacao' 
                where id_empresa = $id_empresa";
        $sql = "update empresa set 
                    capital_inicial = '$capital_inicial' 
                where id_empresa = $id_empresa";

        $conexao = new Conexao();
        $conexao->executar($sql);
    }

    public function deletar($id_empresa)
    {
        $sql = "delete from empresa where id_empresa = $id_empresa";

        $conexao = new Conexao();
        $conexao->executar($sql);
    }

    public function recuperarTodos()
    {
        $sql = "select * from empresa";

        $conexao = new Conexao();
        return $conexao->recuperarTodos($sql);
    }

    public function recuperarPorId($id_empresa)
    {
        $sql = "select * from empresa where id_empresa = $id_empresa";

        $conexao = new Conexao();
        $dados = $conexao->recuperarTodos($sql);

        $this->id_empresa = $dados[0]['id_empresa'];
        $this->razao_social = $dados[0]['razao_social'];
        $this->nome_fantasia = $dados[0]['nome_fantasia'];
        $this->cnpj = $dados[0]['CNPJ'];
        $this->data_fundacao = $dados[0]['data_fundacao'];
        $this->capital_inicial = $dados[0]['capital_inicial'];
    }
}