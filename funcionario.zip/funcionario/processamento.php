<?php

include_once 'Funcionario.php';

$funcionario = new Funcionario();

switch ($_GET['acao']){
    case 'salvar':
        if(empty($_POST['id_funcionario'])){
            $funcionario->inserir($_POST);
        } else {
            $funcionario->alterar($_POST);
        }
        break;
    case 'deletar':
        $funcionario->deletar($_GET['id_funcionario']);
        break;
}

header('location: index.php');