<?php

include_once 'Funcionario.php';

$funcionarios = Funcionario::recuperarTodos();

include_once '../cabecalho.php';
?>

    <div class="row">
    	<div class="col-md-12">

    		<div class="box box-danger">
    			<div class="box-header with-border">
    				<h3 class="box-title">Funcionario</h3>
    			</div>
    			<div class="box-body">
    				<div class="row">
    					<div class="col-md-12">
                            <a class="btn btn-warning" href="formulario.php">Novo</a>
                            <table class="table table-bordered table-striped table-hover datatable">
                                <tr>
                                    <td>Ações</td>
                                    <td>ID</td>
                                    <td>Nome</td>
                                    <td>Matricula</td>
                                    <td>Salário(R$)</td>
                                    <td>Telefone</td>
                                    <td>Endereço</td>
                                    <td>E-mail</td>
                                </tr>
                                <?php
                                foreach ($funcionarios as $funcionario) {
                                    echo "
                <tr>
                    <td>
                        <a class='trash' href='processamento.php?acao=deletar&id_funcionario={$funcionario['id_funcionario']}'><span class='fa fa-trash'></span></a>
                        <a href='formulario.php?id_funcionario={$funcionario['id_funcionario']}'><span class='fa fa-edit'></span></a>
                    </td>
                    <td>{$funcionario['id_funcionario']}</td>
                    <td>{$funcionario['nome']}</td>
                    <td>{$funcionario['matricula']}</td>
                    <td>{$funcionario['salario']}</td>
                    <td>{$funcionario['telefone']}</td>
                    <td>{$funcionario['endereco']}</td>
                    <td>{$funcionario['email']}</td>
                </tr>
            ";
                                }
                                ?>
                            </table>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>

    <script>
    
    //$(function(){

       // swal('Atenção!', 'Deu certo.', 'warning');
   // }
   // )
    
    </script>

<?php include_once '../rodape.php'; ?>