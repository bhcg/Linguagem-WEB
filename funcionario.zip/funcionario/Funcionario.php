<?php

include_once '../Conexao.php';

class Funcionario{

    protected $id_funcionario;
    protected $nome;
    protected $matricula;
    protected $salario;
    protected $telefone;
    protected $endereco;
    protected $email;
    protected $id_cargo;
    protected $id_empresa;

    /**
     * @return mixed
     */
    public function getIdFuncionario()
    {
        return $this->id_funcionario;
    }

    /**
     * @param mixed $id_funcionario
     */
    public function setIdFuncionario($id_funcionario)
    {
        $this->id_funcionario = $id_funcionario;
    }

    /**
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * @param mixed $nome
     */
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    /**
     * @return mixed
     */
    public function getMatricula()
    {
        return $this->matricula;
    }

    /**
     * @param mixed $matricula
     */
    public function setMatricula($matricula)
    {
        $this->matricula = $matricula;
    }

    /**
     * @return mixed
     */
    public function getSalario()
    {
        return $this->salario;
    }

    /**
     * @param mixed $salario
     */
    public function setSalario($salario)
    {
        $this->salario = $salario;
    }

    /**
     * @return mixed
     */
    public function getTelefone()
    {
        return $this->telefone;
    }

    /**
     * @param mixed $telefone
     */
    public function setTelefone($telefone)
    {
        $this->telefone = $telefone;
    }

    /**
     * @return mixed
     */
    public function getEndereco()
    {
        return $this->endereco;
    }

    /**
     * @param mixed $endereco
     */
    public function setEndereco($endereco)
    {
        $this->endereco = $endereco;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getIdCargo()
    {
        return $this->id_cargo;
    }

    /**
     * @param mixed $id_cargo
     */
    public function setIdCargo($id_cargo)
    {
        $this->id_cargo = $id_cargo;
    }

    /**
     * @return mixed
     */
    public function getIdEmpresa()
    {
        return $this->id_empresa;
    }

    /**
     * @param mixed $id_empresa
     */
    public function setIdEmpresa($id_empresa)
    {
        $this->email = $email;
    }

    public function inserir($dados)
    {
        
        $nome = $dados['nome'];
        $matricula = $dados['matricula'];
        $salario = $dados['salario'];
        $telefone = $dados['telefone'];
        $endereco = $dados['endereco'];
        $email = $dados['email'];

        $conexao = new Conexao();
        
        $sql = "insert into funcionario (nome) values ('$nome')";

        return $conexao->executar($sql);
    }

    public function alterar($dados)
    {
        $nome = $dados['nome'];
        $matricula = $dados['matricula'];
        $salario = $dados['salario'];
        $telefone = $dados['telefone'];
        $endereco = $dados['endereco'];
        $email = $dados['email'];

        $sql = "update funcionario set 
                    nome = '$nome' 
                where id_funcionario = $id_funcionario";
        $sql = "update funcionario set 
                    matricula = '$matricula' 
                where id_funcionario = $id_funcionario";
        $sql = "update funcionario set 
                    salario = '$salario' 
                where id_funcionario = $id_funcionario";
        $sql = "update funcionario set 
                    telefone = '$telefone' 
                where id_funcionario = $id_funcionario";
        $sql = "update funcionario set 
                    endereco = '$endereco' 
                where id_funcionario = $id_funcionario";
        $sql = "update funcionario set 
                    email = '$email' 
                where id_funcionario = $id_funcionario";

        $conexao = new Conexao();
        $conexao->executar($sql);
    }

    public function deletar($id_funcionario)
    {
        $sql = "delete from funcionario where id_funcionario = $id_funcionario";

        $conexao = new Conexao();
        $conexao->executar($sql);
    }

    public function recuperarTodos()
    {
        $sql = "select * from funcionario";

        $conexao = new Conexao();
        return $conexao->recuperarTodos($sql);
    }

    public function recuperarPorId($id_funcionario)
    {
        $sql = "select * from funcionario where id_funcionario = $id_funcionario";

        $conexao = new Conexao();
        $dados = $conexao->recuperarTodos($sql);

        $this->id_funcionario = $dados[0]['id_funcionario'];
        $this->nome = $dados[0]['nome'];
        $this->matricula = $dados[0]['matricula'];
        $this->salario = $dados[0]['salario'];
        $this->telefone = $dados[0]['telefone'];
        $this->endereco = $dados[0]['endereco'];
        $this->email = $dados[0]['email'];
    }
}