<?php
include_once 'Funcionario.php';

$funcionario = new Funcionario();

if(!empty($_GET['id_funcionario'])){
    $funcionario->recuperarPorId($_GET['id_funcionario']);
}

include_once '../cabecalho.php';
?>

    <div class="row">
    	<div class="col-md-12">

    		<div class="box box-danger">
    			<div class="box-header with-border">
    				<h3 class="box-title">Funcionário</h3>
    			</div>
    			<div class="box-body">
    				<div class="row">
    					<div class="col-md-12">
                            <form action="processamento.php?acao=salvar" method="post">

                                <input type="hidden" name="id_funcionario" id="id_funcionario" value="<?php echo $funcionario->getIdFuncionario(); ?>">

                                <div class="form-group row">
                                    <label for="nome" class="col-sm-2 col-form-label">Nome:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="nome" id="nome" value="<?php echo $funcionario->getNome(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="matricula" class="col-sm-2 col-form-label">Matricula:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="matricula" id="matricula" value="<?php echo $funcionario->getMatricula(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="salario" class="col-sm-2 col-form-label">Salário(R$):</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="salario" id="salario" value="<?php echo $funcionario->getSalario(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="telefone" class="col-sm-2 col-form-label">Telefone:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="telefone" id="telefone" value="<?php echo $funcionario->getTelefone(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="endereco" class="col-sm-2 col-form-label">Endereço:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="endereco" id="endereco" value="<?php echo $funcionario->getEndereco(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="email" class="col-sm-2 col-form-label">E-mail:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="email" id="email" value="<?php echo $funcionario->getEmail(); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-success">Enviar</button>
                                        <a class="btn btn-danger" href="index.php">Voltar</a>
                                    </div>
                                </div>
                            </form>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>






<?php include_once '../rodape.php'; ?>